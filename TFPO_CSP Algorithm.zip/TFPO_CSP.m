function [error] = TFPO_CSP(Data, Target, Fs)

%**************************************************************************
%**************************************************************************

%**************************************************************************
% Target - (1 x N) vector containing the target classes
% N - total number of trials/samples
% Data - (Nch x T x N) conatins the trials
% Nch - Number of channels
% T - number of sample points
%-*************************************************************************
if nargin < 1
    load('Target');
    load('Data');
    Fs = 100;
end

ind = crossvalind('Kfold',Target,10);
Acc =  zeros(1,10);
error_test = zeros(1,10);

for nfold = 1:10 % 10-fold cross validation
    test = (ind == nfold); 
    test_ind = find(test == 1);
    train = ~test;
    train_ind = find(train == 1);
    
    Train_data = Data(:,:,train_ind);
    Target_Train = Target(train_ind);
    Test_data = Data(:,:,test_ind);
    Target_Test = Target(test_ind);
    
%     [Gbest,Gbest_value,Pbest,Pbest_value,error] = PSO(10, 3, 35, 2.5, Train_data, Target_Train, Fs);
%     Gbest = GA(10, 3, 35, 2.5, Train_data, Target_Train, Fs);
    Gbest = ABC(10, 5, 35, [16.0, 32, 50], [0.5, 18, 1], Train_data, Target_Train,2.5,Fs);
    
[AA,BB] = butter(round(Gbest(3)),[Gbest(1) Gbest(2)]/(Fs/2));
    
    for i=1:length(Target_Train)
        Train_data(:,:,i) = filter(AA,BB,Train_data(:,:,i)')';
    end
    
    for i=1:length(Target_Test)
        Test_data(:,:,i) = filter(AA,BB,Test_data(:,:,i)')';
    end
    
    clear Z
    clear F
    
    [Z, Wcsp] = CSP(Train_data,Target_Train',3);

    for i = 1:1:size(Z,3)
        clear var
        var1 = var(Z(:,:,i)');
        F(i,:) = log(var1); % CSP features 
    end

    clear Z_Test
    clear F_Test

    for i = 1:1:size(Target_Test,2)
        Z_Test(:,:,i) = Wcsp*Test_data(:,:,i); % Z - csp transformed data
        var1 = var(Z_Test(:,:,i)');
        F_Test(i,:) = log(var1); 
    end
    
    MODEL=fitcsvm(F,Target_Train','Solver','L1QP');
    yfit = predict(MODEL,F_Test);
    
    Acc(nfold) = sum(yfit == Target_Test')/length(Target_Test)*100 
    error_test(nfold) = 100 - Acc(nfold);
end

disp('10-fold cross-validation error:') 
mean(error_test)
