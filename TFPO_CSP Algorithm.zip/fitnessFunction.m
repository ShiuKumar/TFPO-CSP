function [error] = fitnessFunction(particle,Training_data,Target_Training, Fs, index)
% particle(1)
% particle(2)
% particle(3)
% Fs = 100;
[AA,BB] = butter(round(particle(3)),[particle(1) particle(2)]/(Fs/2));
% [AA,BB] = butter(8,[7 30]/(Fs/2));

for i=1:length(Target_Training)
    Training_data(:,:,i) = filter(AA,BB,Training_data(:,:,i)')';
end

for num = 1:10  
    %num
    test = (index == num); 
    test_indices = find(test == 1);
    train = ~test;
    train_indices = find(train == 1);
    
    clear Z
    clear F
    [Z, Wcsp] = CSP(Training_data(:,:,train_indices),Target_Training(train_indices)',3);

    for i = 1:1:size(Z,3)
        clear var
        var1 = var(Z(:,:,i)');
        F(i,:) = log(var1);%./log(sum(var1));
    end

    clear var1
    clear Z_Test
    clear F_Test

    for i = 1:1:length(test_indices)
        Z_Test(:,:,i) = Wcsp*Training_data(:,:,test_indices(i)); % Z - csp transformed data
        var1 = var(Z_Test(:,:,i)');
        F_Test(i,:) = log(var1); 
    end
    
    MODEL=fitcsvm(F,Target_Training(train_indices)','Solver','L1QP');
    yfit = predict(MODEL,F_Test);
    
    Acc(num) = sum(yfit == Target_Training(test_indices)')/length(test_indices)*100;
end

error = 100 - mean(Acc(1:num));
