% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YPEA101
% Project Title: Implementation of Binary Genetic Algorithm in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com

function [Gbest,Gbest_value] = GA(Np, D, IterMax, fitnessCondition, TrainData, TargetTrain, Fs)
% tic
% input contains --> Np, D, IterMax, fitnessCondition, TrainData, TargetTrain

% Np - population size
% D - # of parameters to tune or  number of Decision Variables
% IterMax - maximum number of iterations
% fitnessCondition - desired fitness value
% TrainData - n x m (n - number of trials, m - number of sample points) 
% TargetTrain - n x 1

%% Problem Definition

% CostFunction=@(x) fitnessFunction(x);     % Cost Function          

VarSize=[1 D];   % Decision Variables Matrix Size

VarMin = [0.5, 18, 1];         % Lower Bound of Variables - to be modified as per your requirements
VarMax= [16.0, 32, 30];        % Upper Bound of Variables - to be modified as per your requirements

indices = crossvalind('Kfold',TargetTrain,10);
%% GA Parameters
nPop = Np;              % Population Size

pc=0.7;                 % Crossover Percentage
nc=2*round(pc*nPop/2);  % Number of Offsprings (also Parents)
gamma=0.4;              % Extra Range Factor for Crossover

pm=0.3;                 % Mutation Percentage
nm=round(pm*nPop);      % Number of Mutants
mu=0.1;                 % Mutation Rate

TournamentSize=3;   % Tournament Size

pause(0.01); % Due to a bug in older versions of MATLAB

%% Initialization

empty_individual.Position=[];
empty_individual.Cost=[];

pop=repmat(empty_individual,nPop,1);

for i=1:nPop
    % Initialize Position
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    % Evaluation
    pop(i).Cost = fitnessFunction(pop(i).Position, TrainData, TargetTrain, Fs, indices);  
end

% Sort Population
Costs=[pop.Cost];
[Costs, SortOrder]=sort(Costs);
pop=pop(SortOrder);

% Store Best Solution
BestSol=pop(1);

% Array to Hold Best Cost Values
BestCost=zeros(IterMax,1);

% Store Cost
WorstCost=pop(end).Cost;

%% Main Loop
it = 1;

while it <= IterMax
    % Crossover
    popc=repmat(empty_individual,nc/2,2);
    for k=1:nc/2
        i1=TournamentSelection(pop,TournamentSize);
        i2=TournamentSelection(pop,TournamentSize);

        p1=pop(i1);
        p2=pop(i2);
        
        % Apply Crossover  
        x1 = p1.Position;
        x2 = p2.Position;
        
        alpha=unifrnd(-gamma,1+gamma,size(x1));
    
        y1=alpha.*x1+(1-alpha).*x2;
        y2=alpha.*x2+(1-alpha).*x1;

        y1=max(y1,VarMin);
        y1=min(y1,VarMax);
        
        y2=max(y2,VarMin);
        y2=min(y2,VarMax);
    
        popc(k,1).Position = y1;
        popc(k,2).Position = y2;
               
        popc(k,1).Cost= fitnessFunction(popc(k,1).Position, TrainData, TargetTrain, Fs, indices); 
        popc(k,2).Cost= fitnessFunction(popc(k,2).Position, TrainData, TargetTrain, Fs, indices); 
    end
    popc=popc(:);
    
    % Mutation
    popm=repmat(empty_individual,nm,1);
    for k=1:nm
        % Select Parent
        i=randi([1 nPop]);
        p=pop(i);
        
        % Apply Mutation
%         popm(k).Position=Mutate(p.Position,mu,VarMin,VarMax);
        
        x = p.Position;
        
        D=numel(x);
    
        nmu=ceil(mu*D);

        j=randsample(D,nmu);

        sigma=0.1*(VarMax-VarMin);

        y=x;
        y(j)=x(j)+sigma(j)*randn(size(j));

        y=max(y,VarMin);
        popm(k).Position=min(y,VarMax);
        
        % Evaluate Mutant
        popm(k).Cost= fitnessFunction(popm(k).Position, TrainData, TargetTrain, Fs, indices); 
        
    end
    
    % Create Merged Population
    pop=[pop
         popc
         popm]; %#ok
     
    % Sort Population
    Costs=[pop.Cost];
    [Costs, SortOrder]=sort(Costs);
    pop=pop(SortOrder);
    
    % Update Worst Cost
    WorstCost=max(WorstCost,pop(end).Cost);
    
    % Truncation
    pop=pop(1:nPop);
    Costs=Costs(1:nPop);
    
    % Store Best Solution Ever Found
    BestSol=pop(1);
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.Cost;
    
%     time(it) = toc   
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    if BestSol.Cost < fitnessCondition
        it = IterMax;
    end
    
    it = it + 1;
end

Gbest = BestSol.Position;
Gbest_value = BestSol.Cost;
