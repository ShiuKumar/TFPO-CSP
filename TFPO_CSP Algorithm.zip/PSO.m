function [Gbest,Gbest_value,Pbest,Pbest_value,error1] = PSO(Np, D, IterMax, fitnessCondition, TrainData, TargetTrain, Fs)
% Particle Swarm Optimization Parameters:

% Gbest - Global Best Position
% Pbest - Particles Best Position
% Gbest_value - global best fitness value
% Pbest_value - particles best fitness value
% Np = Number of Particles in Swarm
% D = Dimension of Search
% IterMax = Maximum number of Iterations

c1 = 1.4;        %Acceleration Coefficient 1
c2 = 1.4;        %Acceleration Coefficient 2
Vmax = 4.0;      %Maximum Velocity. V is kept in the range [-Vmax, Vmax]
Vmin = -1*Vmax;
Wmax = 0.9;
Wmin = 0.2;


X = zeros(D, Np);       %Swarm of particles (positions) (NOTE: Row = Dimension, Column = Particle)
V = zeros(D, Np);       %Particle velocities
Pbest = zeros(D, Np);   %The best position so far for each particle
Gbest = zeros(D, 1);    %The global best particle
Pbest_value = zeros(1, Np);

%Get the range (min, max) for each dimension 
Xmin = [0.5; 20; 1]; % [lower cutoff freq; upper cutoff freq; filter order]
Xmax = [15; 32; 50]; 

%     W = Wmin + ((Wmax - Wmin)/(IterMax - 1))*(IterMax - p);
delta = 2.01 + (2.40 - 2.01)*rand(1,1);
W = 1/(delta-1+sqrt(delta^2-2*delta));
c1 = 2*W;
c2 = c1;

indices = crossvalind('Kfold',TargetTrain,10);

%Initialize PSO
for m = 1:Np                %For each particle
    %Initilize particle positions
    X(:,m) = Xmin + (Xmax - Xmin).*rand(D,1);
    if X(1,m)>X(2,m)
        X1 = X(1,m);
        X(1,m) = X(2,m);
        X(2,m) = X1;
    end
    
    if X(1,m)> Xmax(1)
       X(1,m)= Xmax(1) ;
    end
    
    if X(2,m)> Xmax(2)
       X(2,m)= Xmax(12);
    end
    
    Pbest(:, m) = X(:, m);
    %Initialize particle velocities
    V(:, m) = Vmin + (Vmax - Vmin).*rand(D,1);
    Pbest_value(1,m) = fitnessFunction(X(:, m), TrainData, TargetTrain, Fs, indices);
    
end
       
%RUN PSO ITERATIONS
p = 1;
while p <= IterMax           %Each Iterations
    for q = 1:Np            %Each Particle
        %Evaluate the desired optimization fitness function:
        error = fitnessFunction(X(:, q), TrainData, TargetTrain, Fs, indices);
        
        if q==1
            error1(p) = error;
        end
        
        if (error < Pbest_value(1, q))   %Minimizing
            Pbest_value(1, q) = error;   %Pbest for each particle
            Pbest(:, q) = X(:, q);
        end 
    end
    [Gbest_value, I] = min(Pbest_value);
    Gbest = Pbest(:, I);      %Particle with the best success so far
    
    for q = 1:Np
       U1(:, 1) = rand(D, 1)*c1;
       U2(:, 1) = rand(D, 1)*c2;
       V(:, q) = W*V(:, q) + U1.*(Pbest(:, q) - X(:, q)) + U2.*(Gbest - X(:, q));    %Change the velocity
       
       %Limit V in interval [-Vmax, Vmax]
       for r = 1:D
           if(V(r,q) < -Vmax)
               V(r, q) = -Vmax;            
           end
           
           if(V(r,q) > Vmax)
               V(r, q) = Vmax;            
           end
       end
       
       %Change/Step the position of each particle
       X(:, q) = X(:, q) + V(:, q); 
       
       for r = 1:D
         if(X(r, q) < Xmin(r, 1))
             X(r, q) = Xmin(r, 1) + 0.15*(Xmin(r, 1) - X(r, q));
         end
         
         if(X(r, q) > Xmax(r, 1))
             X(r, q) = Xmax(r, 1) - 0.15*(X(r, q) - Xmax(r, 1));
         end
       end
       
    end
    
     p1 = p;
    if Gbest_value <=fitnessCondition % Desired fitness value
        p1 = p;
        p = IterMax;
    end
    p = p+1;
end         %End Iterations

%Display Results:
disp('Number of iterations: ');
disp(p1);
disp('Best Position: ');
disp(Gbest);
disp('Best Result: ');
disp(Gbest_value);
